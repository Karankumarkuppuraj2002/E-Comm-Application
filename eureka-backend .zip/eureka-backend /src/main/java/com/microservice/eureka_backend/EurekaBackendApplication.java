package com.microservice.eureka_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EurekaBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(EurekaBackendApplication.class, args);
	}

}
