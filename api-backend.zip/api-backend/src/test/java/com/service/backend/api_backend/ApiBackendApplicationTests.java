package com.service.backend.api_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
